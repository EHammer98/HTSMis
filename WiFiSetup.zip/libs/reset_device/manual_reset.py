import reset_lib

reset_lib.reset_to_host_mode()
